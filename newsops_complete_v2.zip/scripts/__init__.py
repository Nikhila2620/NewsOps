"""NewsOps scripts package."""

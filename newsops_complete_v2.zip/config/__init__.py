"""NewsOps configuration package."""
